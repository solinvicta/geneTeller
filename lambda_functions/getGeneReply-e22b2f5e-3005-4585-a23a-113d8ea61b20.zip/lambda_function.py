import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message
        }
    }


def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response


def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }





s3 = boto3.resource('s3')
bucket = 'geneteller'
key = 'proteinAtlas.json'
obj = s3.Object(bucket, key)
data = json.loads(obj.get()['Body'].read().decode('utf-8') )

def getGeneReply(intent_request):
    try:
        geneValues = intent_request['currentIntent']['slotDetails']["gene"]['resolutions']
        gene = geneValues[0]['value']
    except:
        gene = intent_request['currentIntent']['slots']["gene"]
    
    infotype = intent_request['currentIntent']['slots']["infotype"]
    try:
        reply = data[gene]['Subcellular location']
        if reply == '':
            reply = "I couldn't find a subcellular location for " + gene
        else:
            reply = reply.split(',')
            if len(reply)>1:
                reply[-1] = 'and ' + reply[-1]
            reply = 'The gene ' + gene + ' is found in ' + ', '.join(reply)
        

    except:
        reply = "I couldn't find a record in ProteinAtlas for the gene " + gene
    return close(intent_request['sessionAttributes'],
                 'Fulfilled',
                 {'contentType': 'PlainText',
                  'content': reply})
    
""" --- Intents --- """


def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """

    intent_name = intent_request['currentIntent']['name']

    # Dispatch to your bot's intent handlers
    if intent_name == 'GetGeneInfo':
        return getGeneReply(intent_request)

    raise Exception('Intent with name ' + intent_name + ' not supported')


""" --- Main handler --- """


def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """

    #logger.debug('event.bot.name={}'.format(event['bot']['name']))

    return dispatch(event)