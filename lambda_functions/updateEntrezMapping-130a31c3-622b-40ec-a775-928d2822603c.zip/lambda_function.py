#Build a simple JSON file that allows mapping between gene symbol and entrez
#For human only

import urllib.request
import csv
from io import TextIOWrapper
import gzip
import json
import boto3
from io import BytesIO

s3 = boto3.resource('s3')
bucket = 'geneteller'
key = 'speciesMap.json'
obj = s3.Object(bucket, key)
speciesMap = json.loads(obj.get()['Body'].read().decode('utf-8') )

def lambda_handler(event, context):
    for species in speciesMap.keys():
        url = speciesMap[species]['geneinfo']
        r = urllib.request.urlretrieve(url, '/tmp/Homo_sapiens.gene_info.gz')
    
        output = {}
        with gzip.GzipFile('/tmp/Homo_sapiens.gene_info.gz', 'r') as infile:
                reader = csv.DictReader(TextIOWrapper(infile, 'utf-8'), delimiter='\t')
                for row in reader:
                    key = row['Symbol'].lower()
                    data = row['GeneID']
                    output[key] = data
        data =    json.dumps(output).encode('utf-8')  
        
        # Manage the upload of the data
        gz_body = BytesIO()
        gz = gzip.GzipFile(None, 'wb', 9, gz_body)
        gz.write(data)  
        gz.close()
 
        # Manage the upload of the data
        client = boto3.client('s3')
        client.put_object(Bucket='geneteller', 
        Key= species + '_entrezMap.json',
        ContentType='application/json',  
        ContentEncoding='gzip',  
        Body=gz_body.getvalue())
