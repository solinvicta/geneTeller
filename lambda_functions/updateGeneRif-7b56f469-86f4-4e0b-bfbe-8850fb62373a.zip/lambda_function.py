#Build a simple JSON file that allows mapping between gene symbol and entrez
#For human only

import urllib.request
import csv
from io import TextIOWrapper
import gzip
import json
import boto3
from io import BytesIO
from gzip import GzipFile  

url = 'ftp://ftp.ncbi.nih.gov/gene/GeneRIF/generifs_basic.gz'
r = urllib.request.urlretrieve(url, '/tmp/generifs_basic.gz')

s3 = boto3.resource('s3')
bucket = 'geneteller'
key = 'speciesMap.json'
obj = s3.Object(bucket, key)
speciesMap = json.loads(obj.get()['Body'].read().decode('utf-8') )

def lambda_handler(event, context):
    for species in speciesMap.keys():
    
        s3 = boto3.client('s3')
        key = species + '_entrezMap.json'
        
        retr = s3.get_object(Bucket=bucket, Key=key)
        bytestream = BytesIO(retr['Body'].read())
        entrezMap = json.loads(GzipFile(None, 'rb', fileobj=bytestream).read().decode('utf-8'))
        
        entrezMap = {y:x for x,y in entrezMap.items()}
        notFound = set([])
        
        output = {}
        
        with gzip.GzipFile('/tmp/generifs_basic.gz', 'r') as infile:
            reader = csv.DictReader(TextIOWrapper(infile, 'utf-8'), delimiter='\t', quoting=csv.QUOTE_NONE)
            for row in reader:
                if row['#Tax ID']!=species:
                    continue
                if 'HuGE Navigator' in row['GeneRIF text']:
                    continue
                geneID = row['Gene ID']
                try:
                    geneSymbol = entrezMap[geneID].lower()
                except:
                    if not geneID in notFound:
                        print(geneID + ' not found in mapping')
                        notFound.add(geneID)
                    continue
                if geneSymbol not in output:
                    output[geneSymbol] = []
                output[geneSymbol].append({'generif update' : row['last update timestamp'], 'generif': row['GeneRIF text']})
                
        #Limit to just the 5 most recent to save space
        for g in output.keys():
            output[g] = sorted( output[g], key = lambda i: i['generif update'],reverse=True) 
            output[g] = output[g][0:5]
            
        data =    json.dumps(output).encode('utf-8') 
        
        gz_body = BytesIO()
        gz = gzip.GzipFile(None, 'wb', 9, gz_body)
        gz.write(data)  
        gz.close()
     
        # Manage the upload of the data
        client = boto3.client('s3')
        client.put_object(Bucket='geneteller', 
        Key=species + '_geneRifs.json',
        ContentType='application/json',  
        ContentEncoding='gzip',  
        Body=gz_body.getvalue())
