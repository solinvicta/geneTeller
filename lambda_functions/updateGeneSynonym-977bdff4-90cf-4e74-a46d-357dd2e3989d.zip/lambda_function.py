#Build a simple JSON file that allows mapping between gene symbol and entrez
#For human only

import urllib.request
import csv
from io import TextIOWrapper
import gzip
import json
import boto3
import re
import string
from io import BytesIO
import text2digits

t2n = text2digits.Text2Digits(similarity_threshold=0.9)
dct={'alpha': 'a','beta': 'b','gamma': 'g','epsilon': 'e','zeta': 'z'}
def lambda_handler(event, context):

    url = 'ftp://ftp.ncbi.nih.gov/gene/DATA/GENE_INFO/Mammalia/Homo_sapiens.gene_info.gz'
    r = urllib.request.urlretrieve(url, '/tmp/Homo_sapiens.gene_info.gz')

    output = {}
    with gzip.GzipFile('/tmp/Homo_sapiens.gene_info.gz', 'r') as infile:
            reader = csv.DictReader(TextIOWrapper(infile, 'utf-8'), delimiter='\t')
            for row in reader:
                
                key = row['Symbol'].lower()
                #if key!='tnf':
                #    continue
                geneID = row['GeneID']
                description = row['description']
                fullSynonyms = row['Other_designations'].split('|')

                
                synonyms = row['Synonyms'].split('|') + fullSynonyms + [key, geneID, description]
                #print(synonyms)
                for s in synonyms:
                    s = s.lower()
                    #try:
                        #s = t2n.convert(s, spell_check=True) 
                    #except:
                        #                        print(s + ' failed to convert')
                    s = re.sub('\s+', '', s)
                    s = re.sub('[\W_]+', '', s)
                    for d in dct.keys():
                        s = s.replace(d, dct[d])
                    
                    if s=='':
                        continue
                    if not s in output:
                        output[s] = []
                    output[s].append(key)
                    if key=='tnf':
                        print(s)
    for k in output.keys():
        output[k] = list(set(output[k]))
        output[k].sort()
    
    data =    json.dumps(output, indent=4, sort_keys=True).encode('utf-8')  
    
    # Manage the upload of the data

    gz_body = BytesIO()
    gz = gzip.GzipFile(None, 'wb', 9, gz_body)
    gz.write(data)  
    gz.close()
 
    # Manage the upload of the data
    client = boto3.client('s3')
    client.put_object(Bucket='geneteller', 
    Key='synonymMap.json',
    ContentType='application/json',  
    ContentEncoding='gzip',  
    Body=gz_body.getvalue())
