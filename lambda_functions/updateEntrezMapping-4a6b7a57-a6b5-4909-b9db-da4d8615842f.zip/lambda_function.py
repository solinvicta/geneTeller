#Build a simple JSON file that allows mapping between gene symbol and entrez
#For human only

import urllib.request
import csv
from io import TextIOWrapper
import gzip
import json
import boto3
from io import BytesIO

def lambda_handler(event, context):
    
    url = 'ftp://ftp.ncbi.nih.gov/gene/DATA/GENE_INFO/Mammalia/Homo_sapiens.gene_info.gz'
    r = urllib.request.urlretrieve(url, '/tmp/Homo_sapiens.gene_info.gz')

    output = {}
    with gzip.GzipFile('/tmp/Homo_sapiens.gene_info.gz', 'r') as infile:
            reader = csv.DictReader(TextIOWrapper(infile, 'utf-8'), delimiter='\t')
            for row in reader:
                key = row['Symbol'].lower()
                data = row['GeneID']
                output[key] = data
    data =    json.dumps(output).encode('utf-8')  
    
    # Manage the upload of the data
    gz_body = BytesIO()
    gz = gzip.GzipFile(None, 'wb', 9, gz_body)
    gz.write(data)  
    gz.close()
 
    # Manage the upload of the data
    client = boto3.client('s3')
    client.put_object(Bucket='geneteller', 
    Key='entrezMap.json',
    ContentType='application/json',  
    ContentEncoding='gzip',  
    Body=gz_body.getvalue())
