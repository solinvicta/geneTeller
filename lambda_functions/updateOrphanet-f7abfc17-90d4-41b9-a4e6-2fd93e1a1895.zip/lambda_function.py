#Build a simple JSON file that allows mapping between gene symbol and entrez
#For human only

import urllib.request
import csv
from io import TextIOWrapper
import gzip
import json
import boto3
import xml.etree.ElementTree as ET
from io import BytesIO

def lambda_handler(event, context):
    url = 'http://www.orphadata.org/data/xml/en_product6.xml'
    r = urllib.request.urlretrieve(url, '/tmp/ophannet.xml')
    output = {}
    
    tree = ET.parse('/tmp/ophannet.xml')
    root = tree.getroot()
    count = 0

    for disorder in root.findall('./DisorderList/Disorder'):
        genes = disorder.findall('./DisorderGeneAssociationList/DisorderGeneAssociation/Gene/Symbol')
        genes = [x.text.lower() for x in genes]
        disorderName = disorder.find('Name').text
        for g in genes:
            if not g in output.keys():
                output[g] = []
            output[g].append(disorderName)

    data =    json.dumps(output).encode('utf-8').decode('unicode-escape').encode('utf-8')
    
    gz_body = BytesIO()
    gz = gzip.GzipFile(None, 'wb', 9, gz_body)
    gz.write(data)  
    gz.close()
 
    # Manage the upload of the data
    client = boto3.client('s3')
    client.put_object(Bucket='geneteller', 
    Key='9606orphanet.json',
    ContentType='application/json',  
    ContentEncoding='gzip',  
    Body=gz_body.getvalue())
