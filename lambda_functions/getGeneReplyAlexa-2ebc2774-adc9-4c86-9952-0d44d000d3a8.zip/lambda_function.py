"""
Code based on the template from alexa-skills-kit-color-expert-python
"""

from __future__ import print_function
from io import BytesIO
from gzip import GzipFile
import json
import boto3
import logging
import text2digits
import re

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

t2n = text2digits.Text2Digits(similarity_threshold=0.9)
        
dct={'alpha': 'a','beta': 'b','gamma': 'g','epsilon': 'e','zeta': 'z', 'entrez': '', 'geneid': ''}
#Load the necessary data from JSON
whatever = ''
resources = ['geneRifs','proteinAtlas', 'entrezMap', 'orphanet', 'gtex', 'refSeq']
allData = {}
bucket = 'geneteller'

s3 = boto3.resource('s3')
key = 'speciesMap.json'
obj = s3.Object(bucket, key)
speciesMap = json.loads(obj.get()['Body'].read().decode('utf-8') )

def loadSynonym():
    synonymMap = {}
    #Load the synonym mapper
    for species in speciesMap.keys():
        s3 = boto3.client('s3')

        key = species + '_synonymMap.json'
        print(key)
        retr = s3.get_object(Bucket=bucket, Key=key)
        bytestream = BytesIO(retr['Body'].read())
        synonymMap[species]= json.loads(GzipFile(None, 'rb', fileobj=bytestream).read().decode('utf-8'))
        del s3
    return synonymMap

def loadResources():
    allData = {}
    #Load the different subsets
    for species in speciesMap.keys():
        allData[species] = {}
        for r in resources:
            s3 = boto3.client('s3')
            key = species + '_' + r + '.json'
            try:
                retr = s3.get_object(Bucket=bucket, Key=key)
                bytestream = BytesIO(retr['Body'].read())
                allData[species][r] = json.loads(GzipFile(None, 'rb', fileobj=bytestream).read().decode('utf-8'))
            except:
                allData[species][r] = ''
            del s3
    return allData

synonymMap = loadSynonym()
allData = loadResources()
canonical = set(list(synonymMap['9606'].keys()))

infoIntents = ["GetGeneInfo", "GetTissueExpression", "GetGeneRif", "GetGeneOrphanet", "GetSymbol", "GetSubcellularLocation", 
"GetGeneSummary", "GetTissueSpecificity", "SetGeneSlot", "SetSpeciesSlot"]

# --------------- Helpers that build all of the responses ----------------------

def build_speechlet_response(title, output, reprompt_text, should_end_session):
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': output
        },
        'card': {
            'type': 'Simple',
            'title': "SessionSpeechlet - " + title,
            'content': "SessionSpeechlet - " + output
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }


def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }


# --------------- Functions that control the skill's behavior ------------------

def get_welcome_response():
    """ If we wanted to initialize the session to have some attributes we could
    add those here
    """

    session_attributes = {}
    card_title = "Welcome"
    speech_output = "Welcome to the Gene Teller information service. " \
                    "Please ask for information about a gene of interest" 
    # If the user either does not reply to the welcome message or says something
    # that is not understood, they will be prompted again with this text.
    reprompt_text = "If you are unsure of a place to start, try something like, " \
                    "Tell me the subcellular location of TMEM101."
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def handle_session_end_request():
    card_title = "Session Ended"
    speech_output = "Thanks for talking to Gene Teller. " \
                    "Good luck with your research! "
    # Setting this to true ends the session and exits the skill.
    should_end_session = True
    return build_response({}, build_speechlet_response(
        card_title, speech_output, None, should_end_session))


def create_gene_attributes(gene):
    return {"lastGene": gene}
    
def create_rifCount_attributes(count):
    return {"rifCount": count}


def getGeneInfo(intent, session):
    session_attributes = {}
    card_title = intent['name']
    
    session_attributes = {}
    should_end_session = False
    infotype =''
    reply = ''
    
    if card_title=='GetTissueExpression':
        infotype = 'tissue expression'
        
    if card_title=='GetGeneRif':
        infotype = 'gene rif'
    
    if card_title=='GetSymbol':
        infotype = 'gene symbol'
        
    if card_title=='GetGeneInfo':
        infotype = intent['slots']["infotype"]['value']
        
    if card_title=='GetGeneOrphanet':
        infotype = 'genetic disease'
    
    if card_title=='GetGeneSummary':
        infotype = 'gene summary'
    
    if card_title=='GetTissueSpecificity':
        infotype = 'tissue specificity'
        
    if card_title=='GetSubcellularLocation':
        infotype = 'subcellular location'
    
    if card_title=='SetGeneSlot':
        infotype = 'set gene'
        
    if card_title=='SetSpeciesSlot':
        infotype = 'set species'

    def prepGene(resource):
        if 'gene' in intent['slots']:
            gene = intent['slots']['gene']['value']
        gene = t2n.convert(gene, spell_check=True)
        gene = re.sub('\s+', '', gene)
        gene = re.sub('[\W_]+', '', gene)
        for d in dct.keys():
            gene = gene.replace(d, dct[d])
        gene = gene.lower()
        try:
            #take first gene - try to prompt
            if gene in canonical:
                if resource!='':
                    testMap = allData[species][resource][gene]
                return gene
            gene = synonymMap[gene]
            if len(gene)>1:
                
                gene = [x.upper() for x in gene]
                gene[-1] = ' or ' + gene[-1]
                genes = ', '.join(gene)
                session_attributes['lastInfo'] = infotype
                speech_output = "The requested gene name is ambiguous - did you mean " + genes + '?'
                reprompt_text = 'Please clarify ' + genes
                return build_response(session_attributes, build_speechlet_response(
                    card_title, speech_output, reprompt_text, should_end_session)) 
            else:
                gene = gene[0]
                if resource!='':
                    testMap = allData[resource][gene]
            return gene
        except:
            try:
                geneName = intent['slots']['gene']['value'] 
            except:
                geneName = 'you requested'
            speech_output = "I couldn't find a record in " + resource + " for the gene " + geneName
            reprompt_text = 'Feel free to ask me for more gene information.'
            return build_response(session_attributes, build_speechlet_response(
            card_title, speech_output, reprompt_text, should_end_session))  
        
        
    resourceMap = {'entrez gene': 'entrezMap', 'tissue expression': 'gtex', 'gene rif': 'geneRifs',
    'subcellular location': 'proteinAtlas', 'tissue specificity': 'proteinAtlas', 'genetic disease': 'orphanet', 'gene symbol': 'entrezMap', 'gene summary': 'refSeq', 'set gene': '', 'set species': ''}
    
    lastGene = False
    if session.get('attributes', {}) and "lastGene" in session.get('attributes', {}):
        lastGene = session['attributes']['lastGene']
    
    lastSpecies = '9606'
    
    if session.get('attributes', {}) and "lastSpecies" in session.get('attributes', {}):
        lastSpecies = session['attributes']['lastSpecies']
    
    resource = resourceMap[infotype]
    print(resource)
    
    if not 'value' in intent['slots']['species']:
        species = lastSpecies
    else:
        species = intent['slots']['species']['resolutions']['resolutionsPerAuthority'][0]['values'][0]['value']['id']

    canonical = set(list(synonymMap[species].keys()))
    
    
    if not 'value' in intent['slots']['gene']:
        gene = lastGene
    else:
        gene = prepGene(resource)
        
    if type(gene) is dict:
        return gene
        
    if infotype=='set species':
        session_attributes['lastSpecies'] = species
        if session.get('attributes', {}) and "lastInfo" in session.get('attributes', {}):
            infotype = session['attributes']['lastInfo']
            resource = resourceMap[infotype]
            del session['attributes']['lastInfo']
        else:
            speech_output = "Thank you - I will refer to " + str(species) + ' for future queries.'
            reprompt_text = 'Feel free to ask me for more gene information.'
            return build_response(session_attributes, build_speechlet_response(
                card_title, speech_output, reprompt_text, should_end_session)) 
    
    if infotype=='set gene':
        session_attributes['lastGene'] = gene
        if session.get('attributes', {}) and "lastInfo" in session.get('attributes', {}):
            infotype = session['attributes']['lastInfo']
            resource = resourceMap[infotype]
            del session['attributes']['lastInfo']
        else:
            speech_output = "Thank you - I will refer to " + gene.upper() + ' for future queries.'
            reprompt_text = 'Feel free to ask me for more gene information.'
            return build_response(session_attributes, build_speechlet_response(
                card_title, speech_output, reprompt_text, should_end_session)) 
    
    if allData[species][resource]=='':
        speech_output = "I'm afraid I do not have a suitable resource to answer that question for this species."
        reprompt_text = 'Feel free to ask me for more gene information.'
        return build_response(session_attributes, build_speechlet_response(
            card_title, speech_output, reprompt_text, should_end_session)) 

    data = allData[species][resource]
    
    session_attributes['lastGene'] = gene
    session_attributes['lastSpecies'] = species
    
    if infotype == 'gene symbol':
        reply = 'The canonical gene symbol is ' + gene.upper()
        
    if infotype == 'genetic disease':
        reply = data[gene]
        if reply == '':
            reply = "I couldn't find a record of " + infotype + " for " + gene
        else:
            if len(reply)>1:
                reply[-1] = 'and ' + reply[-1]       
            reply = [''.join([i for i in s if (i.isalpha() or i==' ')]) for s in reply]
            reply = ', '.join(reply)
            reply = 'The gene ' + gene.upper() + ' is associated with ' + reply
    
    if infotype == 'gene summary':
        reply = data[gene]
        if reply == '':
            reply = "I couldn't find a record of " + infotype + " for " + gene
        else:
            
            reply = 'The refseq summary for ' + gene.upper() + ' is: ' + reply
    
    if infotype == 'gene rif':
        rifCount = 0
        if session.get('attributes', {}) and "rifCount" in session.get('attributes', {}):
            rifCount = int(session['attributes']['rifCount'])
        
        if gene!=lastGene:
            reply = data[gene][0]['generif']
            reply = 'The most recent gene rif about ' + gene.upper() + ' is: ' + reply
            session_attributes['rifCount'] = 1
        elif len(data[gene])-1 > rifCount:
            reply = data[gene][rifCount]['generif']
            reply = 'Another gene rif about ' + gene.upper() + ' is: '  + reply
            session_attributes['rifCount'] = rifCount +1
        else:
            reply = "I'm afraid I don't have another gene rif for " + gene.upper()
    
    if infotype == 'entrez gene':
        reply = data[gene]
        reply = "The entrez gene i d for " + gene + ' is ' + str(reply)
        
    if infotype =='tissue expression':
        try:
            if 'value' in intent['slots']['tissue']:
                tissue = intent['slots']['tissue']['value']
            tpm = data[gene][tissue]
            reply = 'The median expression of ' + gene.upper() + ' in the ' + tissue + ' is ' + tpm + ' TPM'
        except:
            tissue = max(data[gene], key=data[gene].get)
            tpm = data[gene][tissue]
            reply = 'The maximum expression of ' + gene.upper() + ' is in the ' + tissue + ' with a median TPM value of ' + tpm
            
    if infotype == 'subcellular location':
        reply = data[gene]['subcellular location']
        if reply == '':
            reply = "I couldn't find a record of " + infotype + " for " + gene
        else:
            reply = reply.split(',')
            if len(reply)>1:
                reply[-1] = 'and ' + reply[-1]
            reply = 'The gene ' + gene + ' is found in ' + ', '.join(reply)

    if infotype == 'tissue specificity':
        reply = data[gene]['rna tissue specificity']
        if reply == '':
            reply = "I couldn't find a record of " + infotype + " for " + gene
        else:
            reply = 'The gene ' + gene + ' has ' + reply + ' tissue specificity.'
        
    speech_output = reply
    reprompt_text = 'Feel free to ask me for more gene information.'


    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


    try:
        geneValues = intent['currentIntent']['slotDetails']["gene"]['resolutions']
        gene = geneValues[0]['value']
    except:
        gene = intent['currentIntent']['slots']["gene"]
    

    return close(intent['sessionAttributes'],
                 'Fulfilled',
                 {'contentType': 'PlainText',
                  'content': reply})



# --------------- Events ------------------

def on_session_started(session_started_request, session):
    """ Called when the session starts """

    print("on_session_started requestId=" + session_started_request['requestId']
          + ", sessionId=" + session['sessionId'])


def on_launch(launch_request, session):
    """ Called when the user launches the skill without specifying what they
    want
    """

    print("on_launch requestId=" + launch_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # Dispatch to your skill's launch
    return get_welcome_response()


def on_intent(intent_request, session):
    """ Called when the user specifies an intent for this skill """

    print("on_intent requestId=" + intent_request['requestId'] +
          ", sessionId=" + session['sessionId'])

    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    # Dispatch to your skill's intent handlers
    if intent_name in infoIntents:
        return getGeneInfo(intent, session)
    elif intent_name == "AMAZON.HelpIntent":
        return get_welcome_response()
    elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    else:
        raise ValueError("Invalid intent")


def on_session_ended(session_ended_request, session):
    """ Called when the user ends the session.
    Is not called when the skill returns should_end_session=true
    """
    print("on_session_ended requestId=" + session_ended_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # add cleanup logic here


# --------------- Main handler ------------------

def lambda_handler(event, context):
    """ Route the incoming request based on type (LaunchRequest, IntentRequest,
    etc.) The JSON body of the request is provided in the event parameter.
    """
    print("event.session.application.applicationId=" +
          event['session']['application']['applicationId'])

    """
    Uncomment this if statement and populate with your skill's application ID to
    prevent someone else from configuring a skill that sends requests to this
    function.
    """
    # if (event['session']['application']['applicationId'] !=
    #         "amzn1.echo-sdk-ams.app.[unique-value-here]"):
    #     raise ValueError("Invalid Application ID")

    if event['session']['new']:
        on_session_started({'requestId': event['request']['requestId']},
                           event['session'])

    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'])
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'])
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended(event['request'], event['session'])