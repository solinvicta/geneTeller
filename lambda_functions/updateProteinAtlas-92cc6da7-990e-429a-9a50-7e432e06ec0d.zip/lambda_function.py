import urllib.request
import gzip
import csv
from io import TextIOWrapper
from zipfile import ZipFile
import json
import boto3
from io import BytesIO


def lambda_handler(event, context):
    proteinAtlasUrl = 'https://www.proteinatlas.org/download/proteinatlas.tsv.zip'
    r = urllib.request.urlretrieve(proteinAtlasUrl, '/tmp/proteinatlas.tsv.zip')
    
    output = {}
    keepCols = ['RNA tissue specificity','RNA tissue specific NX', 'Subcellular location', 'Reliability (IH)']
    
    with ZipFile('/tmp/proteinatlas.tsv.zip') as zf:
        with zf.open('proteinatlas.tsv', 'r') as infile:
            reader = csv.DictReader(TextIOWrapper(infile, 'utf-8'), delimiter='\t')
            for row in reader:
                key = row['Gene'].lower()
                data = { key.lower() :value for key,value in row.items() if key in keepCols}
                output[key] = data
    data =    json.dumps(output).encode('utf-8')  
    
    gz_body = BytesIO()
    gz = gzip.GzipFile(None, 'wb', 9, gz_body)
    gz.write(data)  
    gz.close()
 
    # Manage the upload of the data
    client = boto3.client('s3')
    client.put_object(Bucket='geneteller', 
    Key='proteinAtlas.json',
    ContentType='application/json',  
    ContentEncoding='gzip',  
    Body=gz_body.getvalue())

