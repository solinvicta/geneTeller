#Build a simple JSON file that provides Refseq summary information
#Due to the long runtime hitting Lambda execution limits, this
#function is split per species.  It might make sense to refactor it
#to accept the species id as an event parameter if the species list expands
#more.  

#This particular function builds the resource for mouse

import urllib.request
import csv
from io import TextIOWrapper
import gzip
from gzip import GzipFile
import json
import boto3
from io import BytesIO
from time import sleep
import re

s3 = boto3.resource('s3')
bucket = 'geneteller'
key = 'speciesMap.json'
obj = s3.Object(bucket, key)
speciesMap = json.loads(obj.get()['Body'].read().decode('utf-8') )

entrezMap = {}
for species in speciesMap.keys():
    s3 = boto3.client('s3')
    key = species + '_entrezMap.json'
    
    retr = s3.get_object(Bucket=bucket, Key=key)
    bytestream = BytesIO(retr['Body'].read())
    entrezMap[species] = json.loads(GzipFile(None, 'rb', fileobj=bytestream).read().decode('utf-8'))
    entrezMap[species] = {y:x for x,y in (entrezMap[species].items()) }

output = {}
species = '10090'

def attempt(url, times=3):
    to_raise = None
    for _ in range(times):
        try:
            return urllib.request.urlretrieve(url, '/tmp/entrezOut.json')
        except Exception as err:
            to_raise = err
        #slight sleep to avoid too many request errors
            sleep(1)
    raise to_raise

def lambda_handler(event, context):

    gene_ids = list(set(entrezMap[species].keys()))


    chunk_size = 200;
    cn = int(len(gene_ids)/chunk_size)+1
    for i in range(cn):
        chunk_genes = gene_ids[chunk_size*i:min([chunk_size*(i+1), len(gene_ids)])];
        gids = ','.join([str(s) for s in chunk_genes])
        url = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=gene&retmode=json&id=' + gids;
        
        r = attempt(url)
        
        #slight sleep to avoid too many request errors
        sleep(0.33)
        
        data = json.load(open('/tmp/entrezOut.json', 'r'))
        
        result = [];
        for g in chunk_genes:
             text = re.sub(r'\[.*?\]', '', data['result'][str(g)]['summary']) if str(g) in data['result'] else ''
             output[entrezMap[species][g]] = text
            
    data =    json.dumps(output).encode('utf-8') 
    
    gz_body = BytesIO()
    gz = gzip.GzipFile(None, 'wb', 9, gz_body)
    gz.write(data)  
    gz.close()
 
    # Manage the upload of the data
    client = boto3.client('s3')
    client.put_object(Bucket='geneteller', 
    Key= species + '_refSeq.json',
    ContentType='application/json',  
    ContentEncoding='gzip',  
    Body=gz_body.getvalue())

    return {
        'statusCode': 200,
        'body': json.dumps('Species ' + species + ' refseq updated')
    }