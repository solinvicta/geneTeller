#Build a simple JSON file that allows mapping between gene symbol and entrez
#For human only

import urllib.request
import csv
from io import TextIOWrapper
import gzip
import json
import boto3
import re
import string
from io import BytesIO
import text2digits

t2n = text2digits.Text2Digits(similarity_threshold=0.9)
dct={'alpha': 'a','beta': 'b','gamma': 'g','epsilon': 'e','zeta': 'z'}

s3 = boto3.resource('s3')
bucket = 'geneteller'
key = 'speciesMap.json'
obj = s3.Object(bucket, key)
speciesMap = json.loads(obj.get()['Body'].read().decode('utf-8') )


def lambda_handler(event, context):
    for species in speciesMap.keys():
        url = speciesMap[species]['geneinfo']
        r = urllib.request.urlretrieve(url, '/tmp/gene_info.gz')
    
        output = {}
        with gzip.GzipFile('/tmp/gene_info.gz', 'r') as infile:
                reader = csv.DictReader(TextIOWrapper(infile, 'utf-8'), delimiter='\t')
                for row in reader:
                    
                    key = row['Symbol'].lower()

                    geneID = row['GeneID']
                    description = row['description']
                    fullSynonyms = row['Other_designations'].split('|')
  
                    
                    synonyms = row['Synonyms'].split('|') + fullSynonyms + [key, geneID, description]

                    for s in synonyms:
                        s = s.lower()
                        s = re.sub('\s+', '', s)
                        s = re.sub('[\W_]+', '', s)
                        for d in dct.keys():
                            s = s.replace(d, dct[d])
                        
                        if s=='':
                            continue
                        if not s in output:
                            output[s] = []
                        output[s].append(key)

        for k in output.keys():
            output[k] = list(set(output[k]))
            output[k].sort()
        
        data =    json.dumps(output, indent=4, sort_keys=True).encode('utf-8')  
        
        # Manage the upload of the data
    
        gz_body = BytesIO()
        gz = gzip.GzipFile(None, 'wb', 9, gz_body)
        gz.write(data)  
        gz.close()
     
        # Manage the upload of the data
        client = boto3.client('s3')
        client.put_object(Bucket='geneteller', 
        Key= species+ '_synonymMap.json',
        ContentType='application/json',  
        ContentEncoding='gzip',  
        Body=gz_body.getvalue())
