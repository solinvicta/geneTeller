

#Build a simple JSON file that allows mapping between gene symbol and entrez
#For human only

import urllib.request
import csv
from io import TextIOWrapper
import gzip
import json
import boto3
from io import BytesIO
from gzip import GzipFile  

termMap = json.load(open('gtex_mapping.json', 'r'))

def lambda_handler(event, context):
    
    url = 'https://storage.googleapis.com/gtex_analysis_v8/rna_seq_data/GTEx_Analysis_2017-06-05_v8_RNASeQCv1.1.9_gene_median_tpm.gct.gz'
    r = urllib.request.urlretrieve(url, '/tmp/gtex.gz')

    output = {}
    
    with gzip.open('/tmp/gtex.gz', 'r') as infile:

        #Skip headers
        next(infile)
        next(infile)
        
        reader = csv.DictReader(TextIOWrapper(infile, 'utf-8'), delimiter='\t', quoting=csv.QUOTE_NONE)
        for row in reader:
            geneSymbol = row['Description'].lower()
            exp = {termMap[k]: str(round(float(row[k]), 2)) for k in termMap.keys()}
            output[geneSymbol] = exp

    data =    json.dumps(output).encode('utf-8') 
    
    gz_body = BytesIO()
    gz = gzip.GzipFile(None, 'wb', 9, gz_body)
    gz.write(data)  
    gz.close()
 
    # Manage the upload of the data
    client = boto3.client('s3')
    client.put_object(Bucket='geneteller', 
    Key='9606gtex.json',
    ContentType='application/json',  
    ContentEncoding='gzip',  
    Body=gz_body.getvalue())
